# Week_11_NLP

NLP techniques applied to student feedback and teacher remarks for performance analysis.