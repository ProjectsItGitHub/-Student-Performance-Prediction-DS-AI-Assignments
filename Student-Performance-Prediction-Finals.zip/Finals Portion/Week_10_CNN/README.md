# Week_10_CNN

Conceptual explanation of CNNs and why they are not ideal for tabular student data.