# Week_9_ANN

Artificial Neural Network model for predicting student performance.
Includes preprocessing, model training, and evaluation.