# Week_12_Case_Study

Complete case study on Student Performance Prediction using ML & AI.