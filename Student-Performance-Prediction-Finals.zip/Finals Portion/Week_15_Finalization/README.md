# Week_15_Finalization

Final report summary, results, and future scope.